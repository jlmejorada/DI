﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio05.Modelos.ENT
{
    public class clsPersona
    {
        public String Nombre { get; set; }
        public String Apellido { get; set; }
    }
}
